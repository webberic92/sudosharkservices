This font can be used for both personal and commercial use, as long as we receive a link back at http://www.fonts101.com

The Font is licnsed under Creative Commons CC BY-ND license, more details on the license here https://creativecommons.org/licenses/by-nd/4.0

You can purchase this font for 5$ if you do not wish to provide the link back.